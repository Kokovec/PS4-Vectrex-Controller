/* ========================================
 * Vectrex PS4 Adapter
 * This is firmware for a PS4 wireless controller adapter for the Vectrex
 * All of the project documents can be found here (https://github.com/Kokovec/PS4-Vectrex-Controller)
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 * ========================================
*/
//#include "project.h"
#include "header01.h"

uint16 receive_data();
void send_data(uint16 length);
void Write_To_SPI();            // function that sends data to the DACs
void Check_Select_Press();      // function that checks "Options" button press andd handles it
void Check_Share_Press();       // function that checks "Share" button press and handles it
void Fetch_PS4_Data();          // function that gets PS4 data and handles joy pots
uint8 Return_Button();         // function that returns pointer of button that was pressed
void Blink_Led(uint8 cnt, uint16 rate_ms);  // function that blinks the on-board LED
void reset_buttons();
void recall_eeprom_buttons();

extern uint8 button_flag;       // 0 = no button pressed, 1 = button pressed
extern uint8 select_flag;       // 0 = short pressm 1 = long press


int main(void)
{
    CyGlobalIntEnable; /* Enable global interrupts. */
    Control_Reg_LED_Write(0);
    Control_Reg_Rapid_Fire_Write(0);
    Clock_1_Start();
    Clock_2_Start();
    Clock_3_Start();
    Clock_4_Start();
    Clock_5_Start();
    UART_PSOC_Start();
    SPIM_Start();
    I2C_Start();
    EEPROM_Start();
    Count7_Select_Start();
    Count7_Select_Stop();
    Count7_Select_WriteCounter(127);
    
    //USBUART_PC_Start(0u, USBUART_PC_5V_OPERATION);  // start USB enumeration
    //while(!USBUART_PC_GetConfiguration());          // wait until USB is configured
    //USBUART_PC_EnableOutEP(3);                      // enable USB output endpoint (EP3)
    
    joy_mode = 0;           // set controller to normal joystick mode
    button_flag = 0;
    select_flag = 0;        // Options button: 0 = short press, 1 = long press
    isr_button_Start();
    isr_Select_Start();
    // Form button pointer map, used as LUT for EEPROM stored button map
    pointermap[0] = &ps4.button_left;
    pointermap[1] = &ps4.button_down;
    pointermap[2] = &ps4.button_right;
    pointermap[3] = &ps4.button_up;
    pointermap[4] = &ps4.button_square;
    pointermap[5] = &ps4.button_x;
    pointermap[6] = &ps4.button_circle;
    pointermap[7] = &ps4.button_triangle;
    pointermap[8] = &ps4.button_l1;
    pointermap[9] = &ps4.button_r1;
    pointermap[10] = &ps4.button_l2;
    pointermap[11] = &ps4.button_r2;
    pointermap[12] = &ps4.button_l3;
    pointermap[13] = &ps4.button_r3;
    pointermap[14] = &ps4.button_tpad;
    
    recall_eeprom_buttons();    // recall saved buttons
    
    for(;;)
    {
        // Enable Serial USB if button is pressed
        if(button_flag == 1){
            isr_button_Stop();                              // disable the button's interrupt
            Control_Reg_LED_Write(1);                       // fast LED pulse to tell user searching for USB host
            USBUART_PC_Start(0u, USBUART_PC_5V_OPERATION);  // start USB enumeration
            while(!USBUART_PC_GetConfiguration());          // wait until USB is configured
            USBUART_PC_EnableOutEP(3);                      // enable USB output endpoint (EP3)
            Control_Reg_LED_Write(2);                       // slow LED pulse to signal success to user
            button_flag = 0;                                // reset button press flag
            isr_button_Start();                             // enable the button's interrupt
            for(;;){
                // Check to see if we need to send data to PS4 adapter
                USB_buffer_length = receive_data();
                if(USB_buffer_length > 0){
                    UART_PSOC_PutArray(buffer, USB_buffer_length);
                }
                // Check to see if we need to receive data from PS4 adapter
                buffer_counter = UART_PSOC_GetRxBufferSize();
                if(buffer_counter > 0) {
                    for(x = 0; x < buffer_counter; x++){
                        buffer[x] = UART_PSOC_GetChar();
                    }
                    send_data(buffer_counter);
                }
                // Check if user pressed button (get out of terminal mode)
                if(button_flag == 1){
                    Control_Reg_LED_Write(1);                       // fast LED pulse to tell user stopping USB client
                    USBUART_PC_Stop();                              // Stop USBUART (disconnect from host)
                    Control_Reg_LED_Write(0);                       // turn off LED
                    button_flag = 0;                                // reset button press flag
                    break;
                }
            }
        }
        // Handle the PS4 controller
        
        Fetch_PS4_Data();
        
        // Handle the buttons
        Control_Reg_Buttons_1_Write(!*joy1_1);
        Control_Reg_Buttons_2_Write(!*joy1_2);
        Control_Reg_Buttons_3_Write(!*joy1_3);
        Control_Reg_Buttons_4_Write(!*joy1_4);
        Control_Reg_Buttons_5_Write(!*joy2_1);
        Control_Reg_Buttons_6_Write(!*joy2_2);
        Control_Reg_Buttons_7_Write(!*joy2_3);
        Control_Reg_Buttons_8_Write(!*joy2_4);
       
        Check_Select_Press();
        Check_Share_Press();
    }
}

uint16 receive_data()
{
    uint16 buffer_length;
    // Check for no data in USBUART buffer
    if(USBUART_PC_GetEPState(3) == USBUART_PC_OUT_BUFFER_EMPTY){
        return 0;                                   // report back that there is no data
    }
    buffer_length = USBUART_PC_GetEPCount(3);       // Get the length of received data
    USBUART_PC_ReadOutEP(3, buffer, buffer_length); // Get the data
    return buffer_length;                           // return buffer lenght
}

void send_data(uint16 buffer_length)
{
    while(USBUART_PC_GetEPState(2) != USBUART_PC_IN_BUFFER_EMPTY); // Wait until our INEP is empty
    USBUART_PC_LoadInEP(2, buffer, buffer_length); // Echo the data back into the buffer
}

void Write_To_SPI()
{
    uint8 temp;
    
    // Clear the TX buffer
    SPIM_ClearTxBuffer();
    // Ensure that previous SPI write is done, or SPI is idle before sending data
    temp = SPIM_ReadTxStatus();
    while(!(temp & (SPIM_STS_SPI_DONE | SPIM_STS_SPI_IDLE)));
    // Send the data
    SPIM_PutArray(buffer, 4);
    // Ensure data is sent before returning from function
    while( ! (SPIM_ReadTxStatus() & SPIM_STS_BYTE_COMPLETE  ) );
}


/*  
    Here to check if "Option" button has been pressed
    A long press (~2 seconds) will place adapter in button config mode
    A short press (<2 seconds) will reset buttons to factory settings
*/
void Check_Select_Press()
{
    uint8 cnt;
    uint8 check_flag[8];
    // check if Option button pressed
    if (ps4.button_options == 1)
    {
        Count7_Select_Enable();             // Start 2 second countdown
        // wait for Option button to be released
        while (ps4.button_options == 1) {
            Fetch_PS4_Data();
            // check if held longer than 2 seconds
            if (select_flag == 1)
            {
                Control_Reg_LED_Write(3);           // turn on LED
            }   
        }  
        Count7_Select_Stop();               // stop countdown timer
        Count7_Select_WriteCounter(127);    // reset countdown timer
        
        // check if in button program mode
        if (select_flag == 1)
        {
            // get button J1-1
            check_flag[0] = 255;
            while (check_flag[0] == 255) check_flag[0] = Return_Button();   // wait for button press
            joy1_1 = pointermap[check_flag[0]];                             // get the new button
            while(*joy1_1 == 1) Fetch_PS4_Data();                           // wait for button release
            //flash LED twice
            Blink_Led(2, 50);
            
            // get button J1-2
            check_flag[1] = 255;
            while (check_flag[1] == 255) check_flag[1] = Return_Button();   // wait for button press
            joy1_2 = pointermap[check_flag[1]];                             // get the new button
            while(*joy1_2 == 1) Fetch_PS4_Data();                           // wait for button release
            //flash LED twice
            Blink_Led(2, 50);
            
            // get button J1-3
            check_flag[2] = 255;
            while (check_flag[2] == 255) check_flag[2] = Return_Button();   // wait for button press
            joy1_3 = pointermap[check_flag[2]];                             // get the new button
            while(*joy1_3 == 1) Fetch_PS4_Data();                           // wait for button release
            //flash LED twice
            Blink_Led(2, 50);
            
            // get button J1-4
            check_flag[3] = 255;
            while (check_flag[3] == 255) check_flag[3] = Return_Button();   // wait for button press
            joy1_4 = pointermap[check_flag[3]];                             // get the new button
            while(*joy1_4 == 1) Fetch_PS4_Data();                           // wait for button release
            //flash LED twice
            Blink_Led(2, 50);
            
            // get button J2-1
            check_flag[4] = 255;
            while (check_flag[4] == 255) check_flag[4] = Return_Button();   // wait for button press
            joy2_1 = pointermap[check_flag[4]];                             // get the new button
            while(*joy2_1 == 1) Fetch_PS4_Data();                           // wait for button release
            //flash LED twice
            Blink_Led(2, 50);
            
            // get button J2-2
            check_flag[5] = 255;
            while (check_flag[5] == 255) check_flag[5] = Return_Button();   // wait for button press
            joy2_2 = pointermap[check_flag[5]];                             // get the new button
            while(*joy2_2 == 1) Fetch_PS4_Data();                           // wait for button release
            //flash LED twice
            Blink_Led(2, 50);
            
            // get button J2-3
            check_flag[6] = 255;
            while (check_flag[6] == 255) check_flag[6] = Return_Button();   // wait for button press
            joy2_3 = pointermap[check_flag[6]];                             // get the new button
            while(*joy2_3 == 1) Fetch_PS4_Data();                           // wait for button release
            //flash LED twice
            Blink_Led(2, 50);
            
            // get button J2-4
            check_flag[7] = 255;
            while (check_flag[7] == 255) check_flag[7] = Return_Button();   // wait for button press
            joy2_4 = pointermap[check_flag[7]];                             // get the new button
            while(*joy2_4 == 1) Fetch_PS4_Data();                               // wait for button release
            
            // Save to EEPROM
            EEPROM_UpdateTemperature();                     // get ready to write to EEPROM
            for(cnt=0; cnt <8; cnt++)
            {
                EEPROM_WriteByte(check_flag[cnt], cnt);     // save button to EEPROM
            }
            
            //flash LED quickly
            Control_Reg_LED_Write(1);           // turn off LED
            CyDelay(500);
        }
        // handle short press (factory reset button)
        else
        {
            reset_buttons();
            //flash LED quickly
            Control_Reg_LED_Write(1);           // turn off LED
            CyDelay(500);
        }
        Control_Reg_LED_Write(0);           // turn off LED
        select_flag = 0;                   // reset isr flag
    }
}

/*
    This function returns the 'pointermap' array location of a button press
    This is the value that will be saved in EEPROM
    It is used by Check_Select_Press() 
*/
uint8 Return_Button()
{
    Fetch_PS4_Data();
    if(ps4.button_left) return 0;
    if(ps4.button_down) return 1;
    if(ps4.button_right) return 2;
    if(ps4.button_up) return 3;
    if(ps4.button_square) return 4;
    if(ps4.button_x) return 5;
    if(ps4.button_circle) return 6;
    if(ps4.button_triangle) return 7;
    if(ps4.button_l1) return 8;
    if(ps4.button_r1) return 9;
    if(ps4.button_l2) return 10;
    if(ps4.button_r2) return 11;
    if(ps4.button_l3) return 12;
    if(ps4.button_r3) return 13;
    if(ps4.button_tpad) return 14;
    return 255;
}

// Fetch PS4 data
void Fetch_PS4_Data()
{
    I2C_buffer[0] = 0;
    I2C_MasterWriteBuf(41, I2C_buffer, 1, I2C_MODE_COMPLETE_XFER);
    CyDelayUs(500);
    I2C_MasterReadBuf(41, buffer, 14, I2C_MODE_COMPLETE_XFER);
    ps4.l_joystick_x = buffer[0];
    ps4.l_joystick_y = buffer[1];
    ps4.r_joystick_x = buffer[2];
    ps4.r_joystick_y = buffer[3];
    ps4.accel_x      = buffer[4];
    ps4.accel_y      = buffer[5]; 
    ps4.l2           = buffer[6]; 
    ps4.r2           = buffer[7]; 
             
    if(((buffer[8]&0x0F)==5) || ((buffer[8]&0x0F)==6) || ((buffer[8]&0x0F)==7)) ps4.button_left=1;  else ps4.button_left=0;	//W
    if(((buffer[8]&0x0F)==3) || ((buffer[8]&0x0F)==4) || ((buffer[8]&0x0F)==5)) ps4.button_down=1;  else ps4.button_down=0;	//S
    if(((buffer[8]&0x0F)==1) || ((buffer[8]&0x0F)==2) || ((buffer[8]&0x0F)==3)) ps4.button_right=1; else ps4.button_right=0;	//E
    if(((buffer[8]&0x0F)==0) || ((buffer[8]&0x0F)==1) || ((buffer[8]&0x0F)==7)) ps4.button_up=1;    else ps4.button_up=0;	//N
    ps4.button_square  =((buffer[8]&0b00010000)>>4); // SQUARE
    ps4.button_x       =((buffer[8]&0b00100000)>>5); // X
    ps4.button_circle  =((buffer[8]&0b01000000)>>6); // CIRCLE
    ps4.button_triangle=((buffer[8]&0b10000000)>>7); // TRIANGLE

    ps4.button_l1     =((buffer[9]&0b00000001));    // L1
    ps4.button_r1     =((buffer[9]&0b00000010)>>1); // R1
    ps4.button_l2     =((buffer[9]&0b00000100)>>2); // L2
    ps4.button_r2     =((buffer[9]&0b00001000)>>3); // R2
    ps4.button_share  =((buffer[9]&0b00010000)>>4); // SHARE
    ps4.button_options=((buffer[9]&0b00100000)>>5); // OPTIONS
    ps4.button_l3     =((buffer[9]&0b01000000)>>6); // L3
    ps4.button_r3     =((buffer[9]&0b10000000)>>7); // R3

    ps4.button_ps4    =((buffer[10]&0b00000001));    // PS4
    ps4.button_tpad   =((buffer[10]&0b00000010)>>1); // TPAD
                
    ps4.tpad_x        =buffer[11]; 
    ps4.tpad_y        =buffer[12];      
    ps4.battery       =buffer[13];  
    
    // Send data Joy data to digi pots (writes buffer[0..3])
    // normal joy mode
    if(joy_mode == 0)
    {
        buffer[2] = ps4.l_joystick_x;
        buffer[3] = ps4.l_joystick_y;
        buffer[0] = ps4.r_joystick_x;
        buffer[1] = ps4.r_joystick_y;
    }
    // joys swapped
    else if(joy_mode == 1)
    {
        buffer[2] = ps4.r_joystick_x;
        buffer[3] = ps4.r_joystick_y;
        buffer[0] = ps4.l_joystick_x;
        buffer[1] = ps4.l_joystick_y;
    }
    // joy mode = 2
    // t-pad
    else
    {
        buffer[2] = ps4.tpad_x;
        buffer[3] = ps4.tpad_y;
        buffer[0] = ps4.r_joystick_x;
        buffer[1] = ps4.r_joystick_y;
    }
    Write_To_SPI();
    
    CyDelay(20);
}

// Flashed LED, leaves it ON when done
void Blink_Led(uint8 cnt, uint16 rate_ms)
{
    uint8 a;
    for(a = 0; a < cnt; a++)
    {
        Control_Reg_LED_Write(0);           // turn off OFF
        CyDelay(rate_ms);
        Control_Reg_LED_Write(3);           // turn off ON
        CyDelay(rate_ms);
    }
}

// This function resets button mapping to factory settings
void reset_buttons()
{
    // declare button map pointers
    joy1_1 = &ps4.button_square;
    joy1_2 = &ps4.button_triangle;
    joy1_3 = &ps4.button_circle;
    joy1_4 = &ps4.button_x;
    joy2_1 = &ps4.button_left;
    joy2_2 = &ps4.button_up;
    joy2_3 = &ps4.button_right;
    joy2_4 = &ps4.button_down;
}

/*  This function recalls the saved buttons from EEPROM
    Each EEPROM address holds a byte value (0 - 13) representing a button
    That value is then mapped to an array of pointers (pointermap)
    The address of the relative ps4 struct member is passed into the joyX_X pointer
*/
void recall_eeprom_buttons()
{
    joy1_1 = pointermap[EEPROM_ReadByte(0)];
    joy1_2 = pointermap[EEPROM_ReadByte(1)];
    joy1_3 = pointermap[EEPROM_ReadByte(2)];
    joy1_4 = pointermap[EEPROM_ReadByte(3)];
    joy2_1 = pointermap[EEPROM_ReadByte(4)];
    joy2_2 = pointermap[EEPROM_ReadByte(5)];
    joy2_3 = pointermap[EEPROM_ReadByte(6)];
    joy2_4 = pointermap[EEPROM_ReadByte(7)];
}

/*
    This function programs autofire buttons
    Enter by long pressing the Share button
    Then select the buttons that you want to set to autofire
    You can select up to 8 buttons
    To get out of this mode:
        1) automatically exits after pressing all 8 buttons
        2) press Share button again (at any time)
    To take all button out of autofire mode:
        1) long press Share button
        2) short press Share button again
*/
void Check_Share_Press()
{
    uint8 auto_fire_status = 0;
    uint8 check_flag;
    uint8 exit_flag = 0;
    // check if Share button pressed
    if (ps4.button_share == 1)
    {
         Count7_Select_Enable();             // Start 2 second countdown
        // wait for Option button to be released
        while (ps4.button_share == 1) {
            Fetch_PS4_Data();
            // check if held longer than 2 seconds
            if (select_flag == 1)
            {
                Control_Reg_LED_Write(3);           // turn on LED
            }   
        }  
        Count7_Select_Stop();               // stop countdown timer
        Count7_Select_WriteCounter(127);    // reset countdown timer
        
        // check if in button autofire program mode mode (Long Press)
        if (select_flag == 1)
        {
            // Get a button
            for(x=0; x <8; x++)
            {
                check_flag = 255;
                exit_flag = 0;
                // wait until uses presses a button
                while (check_flag == 255)
                {
                    check_flag = Return_Button();   // check for button press
                    Fetch_PS4_Data();
                    // Check if Option Button was pressed
                    if(ps4.button_share == 1)
                    {
                        exit_flag = 1;
                        break;
                    }
                }
                // Check if Option Button was pressed again (get out of autofire pgm mode)
                if(exit_flag == 1)
                {
                    // wait for Option button to be released
                    while (ps4.button_share == 1) 
                    {
                        Fetch_PS4_Data();
                    }
                    break;
                }
                // a button was pressed
                while(*pointermap[check_flag] == 1) Fetch_PS4_Data();   // wait for button release
                // Set button to autofire mode if it's currently assigned
                if(pointermap[check_flag] == joy1_1) auto_fire_status |= 0b00000001;
                if(pointermap[check_flag] == joy1_2) auto_fire_status |= 0b00000010;
                if(pointermap[check_flag] == joy1_3) auto_fire_status |= 0b00000100;
                if(pointermap[check_flag] == joy1_4) auto_fire_status |= 0b00001000;
                if(pointermap[check_flag] == joy2_1) auto_fire_status |= 0b00010000;
                if(pointermap[check_flag] == joy2_2) auto_fire_status |= 0b00100000;
                if(pointermap[check_flag] == joy2_3) auto_fire_status |= 0b01000000;
                if(pointermap[check_flag] == joy2_4) auto_fire_status |= 0b10000000;
                //flash LED twice
                Blink_Led(2, 50);
            }
            // get out of here
            Control_Reg_Rapid_Fire_Write(auto_fire_status);
            Control_Reg_LED_Write(0);           // turn off LED
            //flash LED quickly
            Control_Reg_LED_Write(1);           // turn off LED
            CyDelay(500);
            Control_Reg_LED_Write(0);           // turn off LED
        }
        // Here for short press (joystick mode config)
        if(select_flag == 0)
        {
            //flash LED quickly
            Control_Reg_LED_Write(1);           // flash LED
            CyDelay(500);
            Control_Reg_LED_Write(3);           // turn ON LED
            check_flag = 255;
            for(;;)
            {
                while (check_flag == 255) check_flag = Return_Button();   // check for button press
                // check for left joy button
                if(check_flag == 12)
                {
                    joy_mode = 0;
                    break;
                }
                // check for right joy button
                if(check_flag == 13)
                {
                    joy_mode = 1;
                    break;
                }
                // check for t-pad button
                if(check_flag == 14)
                {
                    joy_mode = 2;
                    break;
                }
            }
            //flash LED quickly
            Control_Reg_LED_Write(1);           // flash LED
            CyDelay(500);
            Control_Reg_LED_Write(0);           // turn ON LED
        }
    }
    select_flag = 0;
}


/* [] END OF FILE */
