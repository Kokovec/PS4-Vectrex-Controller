/*******************************************************************************
* File Name: USBFS_PC_Dp.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_USBFS_PC_Dp_H) /* Pins USBFS_PC_Dp_H */
#define CY_PINS_USBFS_PC_Dp_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "USBFS_PC_Dp_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 USBFS_PC_Dp__PORT == 15 && ((USBFS_PC_Dp__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    USBFS_PC_Dp_Write(uint8 value);
void    USBFS_PC_Dp_SetDriveMode(uint8 mode);
uint8   USBFS_PC_Dp_ReadDataReg(void);
uint8   USBFS_PC_Dp_Read(void);
void    USBFS_PC_Dp_SetInterruptMode(uint16 position, uint16 mode);
uint8   USBFS_PC_Dp_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the USBFS_PC_Dp_SetDriveMode() function.
     *  @{
     */
        #define USBFS_PC_Dp_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define USBFS_PC_Dp_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define USBFS_PC_Dp_DM_RES_UP          PIN_DM_RES_UP
        #define USBFS_PC_Dp_DM_RES_DWN         PIN_DM_RES_DWN
        #define USBFS_PC_Dp_DM_OD_LO           PIN_DM_OD_LO
        #define USBFS_PC_Dp_DM_OD_HI           PIN_DM_OD_HI
        #define USBFS_PC_Dp_DM_STRONG          PIN_DM_STRONG
        #define USBFS_PC_Dp_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define USBFS_PC_Dp_MASK               USBFS_PC_Dp__MASK
#define USBFS_PC_Dp_SHIFT              USBFS_PC_Dp__SHIFT
#define USBFS_PC_Dp_WIDTH              1u

/* Interrupt constants */
#if defined(USBFS_PC_Dp__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in USBFS_PC_Dp_SetInterruptMode() function.
     *  @{
     */
        #define USBFS_PC_Dp_INTR_NONE      (uint16)(0x0000u)
        #define USBFS_PC_Dp_INTR_RISING    (uint16)(0x0001u)
        #define USBFS_PC_Dp_INTR_FALLING   (uint16)(0x0002u)
        #define USBFS_PC_Dp_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define USBFS_PC_Dp_INTR_MASK      (0x01u) 
#endif /* (USBFS_PC_Dp__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define USBFS_PC_Dp_PS                     (* (reg8 *) USBFS_PC_Dp__PS)
/* Data Register */
#define USBFS_PC_Dp_DR                     (* (reg8 *) USBFS_PC_Dp__DR)
/* Port Number */
#define USBFS_PC_Dp_PRT_NUM                (* (reg8 *) USBFS_PC_Dp__PRT) 
/* Connect to Analog Globals */                                                  
#define USBFS_PC_Dp_AG                     (* (reg8 *) USBFS_PC_Dp__AG)                       
/* Analog MUX bux enable */
#define USBFS_PC_Dp_AMUX                   (* (reg8 *) USBFS_PC_Dp__AMUX) 
/* Bidirectional Enable */                                                        
#define USBFS_PC_Dp_BIE                    (* (reg8 *) USBFS_PC_Dp__BIE)
/* Bit-mask for Aliased Register Access */
#define USBFS_PC_Dp_BIT_MASK               (* (reg8 *) USBFS_PC_Dp__BIT_MASK)
/* Bypass Enable */
#define USBFS_PC_Dp_BYP                    (* (reg8 *) USBFS_PC_Dp__BYP)
/* Port wide control signals */                                                   
#define USBFS_PC_Dp_CTL                    (* (reg8 *) USBFS_PC_Dp__CTL)
/* Drive Modes */
#define USBFS_PC_Dp_DM0                    (* (reg8 *) USBFS_PC_Dp__DM0) 
#define USBFS_PC_Dp_DM1                    (* (reg8 *) USBFS_PC_Dp__DM1)
#define USBFS_PC_Dp_DM2                    (* (reg8 *) USBFS_PC_Dp__DM2) 
/* Input Buffer Disable Override */
#define USBFS_PC_Dp_INP_DIS                (* (reg8 *) USBFS_PC_Dp__INP_DIS)
/* LCD Common or Segment Drive */
#define USBFS_PC_Dp_LCD_COM_SEG            (* (reg8 *) USBFS_PC_Dp__LCD_COM_SEG)
/* Enable Segment LCD */
#define USBFS_PC_Dp_LCD_EN                 (* (reg8 *) USBFS_PC_Dp__LCD_EN)
/* Slew Rate Control */
#define USBFS_PC_Dp_SLW                    (* (reg8 *) USBFS_PC_Dp__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define USBFS_PC_Dp_PRTDSI__CAPS_SEL       (* (reg8 *) USBFS_PC_Dp__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define USBFS_PC_Dp_PRTDSI__DBL_SYNC_IN    (* (reg8 *) USBFS_PC_Dp__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define USBFS_PC_Dp_PRTDSI__OE_SEL0        (* (reg8 *) USBFS_PC_Dp__PRTDSI__OE_SEL0) 
#define USBFS_PC_Dp_PRTDSI__OE_SEL1        (* (reg8 *) USBFS_PC_Dp__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define USBFS_PC_Dp_PRTDSI__OUT_SEL0       (* (reg8 *) USBFS_PC_Dp__PRTDSI__OUT_SEL0) 
#define USBFS_PC_Dp_PRTDSI__OUT_SEL1       (* (reg8 *) USBFS_PC_Dp__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define USBFS_PC_Dp_PRTDSI__SYNC_OUT       (* (reg8 *) USBFS_PC_Dp__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(USBFS_PC_Dp__SIO_CFG)
    #define USBFS_PC_Dp_SIO_HYST_EN        (* (reg8 *) USBFS_PC_Dp__SIO_HYST_EN)
    #define USBFS_PC_Dp_SIO_REG_HIFREQ     (* (reg8 *) USBFS_PC_Dp__SIO_REG_HIFREQ)
    #define USBFS_PC_Dp_SIO_CFG            (* (reg8 *) USBFS_PC_Dp__SIO_CFG)
    #define USBFS_PC_Dp_SIO_DIFF           (* (reg8 *) USBFS_PC_Dp__SIO_DIFF)
#endif /* (USBFS_PC_Dp__SIO_CFG) */

/* Interrupt Registers */
#if defined(USBFS_PC_Dp__INTSTAT)
    #define USBFS_PC_Dp_INTSTAT            (* (reg8 *) USBFS_PC_Dp__INTSTAT)
    #define USBFS_PC_Dp_SNAP               (* (reg8 *) USBFS_PC_Dp__SNAP)
    
	#define USBFS_PC_Dp_0_INTTYPE_REG 		(* (reg8 *) USBFS_PC_Dp__0__INTTYPE)
#endif /* (USBFS_PC_Dp__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_USBFS_PC_Dp_H */


/* [] END OF FILE */
