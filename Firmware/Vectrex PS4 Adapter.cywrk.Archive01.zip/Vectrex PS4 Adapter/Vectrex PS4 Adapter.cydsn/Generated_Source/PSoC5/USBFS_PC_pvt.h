/***************************************************************************//**
* \file .h
* \version 3.20
*
* \brief
*  This file provides private function prototypes and constants for the 
*  USBFS component. It is not intended to be used in the user project.
*
********************************************************************************
* \copyright
* Copyright 2013-2016, Cypress Semiconductor Corporation. All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_USBFS_USBFS_PC_pvt_H)
#define CY_USBFS_USBFS_PC_pvt_H

#include "USBFS_PC.h"
   
#ifdef USBFS_PC_ENABLE_AUDIO_CLASS
    #include "USBFS_PC_audio.h"
#endif /* USBFS_PC_ENABLE_AUDIO_CLASS */

#ifdef USBFS_PC_ENABLE_CDC_CLASS
    #include "USBFS_PC_cdc.h"
#endif /* USBFS_PC_ENABLE_CDC_CLASS */

#if (USBFS_PC_ENABLE_MIDI_CLASS)
    #include "USBFS_PC_midi.h"
#endif /* (USBFS_PC_ENABLE_MIDI_CLASS) */

#if (USBFS_PC_ENABLE_MSC_CLASS)
    #include "USBFS_PC_msc.h"
#endif /* (USBFS_PC_ENABLE_MSC_CLASS) */

#if (USBFS_PC_EP_MANAGEMENT_DMA)
    #if (CY_PSOC4)
        #include <CyDMA.h>
    #else
        #include <CyDmac.h>
        #if ((USBFS_PC_EP_MANAGEMENT_DMA_AUTO) && (USBFS_PC_EP_DMA_AUTO_OPT == 0u))
            #include "USBFS_PC_EP_DMA_Done_isr.h"
            #include "USBFS_PC_EP8_DMA_Done_SR.h"
            #include "USBFS_PC_EP17_DMA_Done_SR.h"
        #endif /* ((USBFS_PC_EP_MANAGEMENT_DMA_AUTO) && (USBFS_PC_EP_DMA_AUTO_OPT == 0u)) */
    #endif /* (CY_PSOC4) */
#endif /* (USBFS_PC_EP_MANAGEMENT_DMA) */

#if (USBFS_PC_DMA1_ACTIVE)
    #include "USBFS_PC_ep1_dma.h"
    #define USBFS_PC_EP1_DMA_CH     (USBFS_PC_ep1_dma_CHANNEL)
#endif /* (USBFS_PC_DMA1_ACTIVE) */

#if (USBFS_PC_DMA2_ACTIVE)
    #include "USBFS_PC_ep2_dma.h"
    #define USBFS_PC_EP2_DMA_CH     (USBFS_PC_ep2_dma_CHANNEL)
#endif /* (USBFS_PC_DMA2_ACTIVE) */

#if (USBFS_PC_DMA3_ACTIVE)
    #include "USBFS_PC_ep3_dma.h"
    #define USBFS_PC_EP3_DMA_CH     (USBFS_PC_ep3_dma_CHANNEL)
#endif /* (USBFS_PC_DMA3_ACTIVE) */

#if (USBFS_PC_DMA4_ACTIVE)
    #include "USBFS_PC_ep4_dma.h"
    #define USBFS_PC_EP4_DMA_CH     (USBFS_PC_ep4_dma_CHANNEL)
#endif /* (USBFS_PC_DMA4_ACTIVE) */

#if (USBFS_PC_DMA5_ACTIVE)
    #include "USBFS_PC_ep5_dma.h"
    #define USBFS_PC_EP5_DMA_CH     (USBFS_PC_ep5_dma_CHANNEL)
#endif /* (USBFS_PC_DMA5_ACTIVE) */

#if (USBFS_PC_DMA6_ACTIVE)
    #include "USBFS_PC_ep6_dma.h"
    #define USBFS_PC_EP6_DMA_CH     (USBFS_PC_ep6_dma_CHANNEL)
#endif /* (USBFS_PC_DMA6_ACTIVE) */

#if (USBFS_PC_DMA7_ACTIVE)
    #include "USBFS_PC_ep7_dma.h"
    #define USBFS_PC_EP7_DMA_CH     (USBFS_PC_ep7_dma_CHANNEL)
#endif /* (USBFS_PC_DMA7_ACTIVE) */

#if (USBFS_PC_DMA8_ACTIVE)
    #include "USBFS_PC_ep8_dma.h"
    #define USBFS_PC_EP8_DMA_CH     (USBFS_PC_ep8_dma_CHANNEL)
#endif /* (USBFS_PC_DMA8_ACTIVE) */


/***************************************
*     Private Variables
***************************************/

/* Generated external references for descriptors. */
extern const uint8 CYCODE USBFS_PC_DEVICE0_DESCR[18u];
extern const uint8 CYCODE USBFS_PC_DEVICE0_CONFIGURATION0_DESCR[25u];
extern const T_USBFS_PC_EP_SETTINGS_BLOCK CYCODE USBFS_PC_DEVICE0_CONFIGURATION0_EP_SETTINGS_TABLE[1u];
extern const uint8 CYCODE USBFS_PC_DEVICE0_CONFIGURATION0_INTERFACE_CLASS[1u];
extern const T_USBFS_PC_LUT CYCODE USBFS_PC_DEVICE0_CONFIGURATION0_TABLE[4u];
extern const T_USBFS_PC_LUT CYCODE USBFS_PC_DEVICE0_TABLE[3u];
extern const T_USBFS_PC_LUT CYCODE USBFS_PC_TABLE[1u];


extern const uint8 CYCODE USBFS_PC_MSOS_DESCRIPTOR[USBFS_PC_MSOS_DESCRIPTOR_LENGTH];
extern const uint8 CYCODE USBFS_PC_MSOS_CONFIGURATION_DESCR[USBFS_PC_MSOS_CONF_DESCR_LENGTH];
#if defined(USBFS_PC_ENABLE_IDSN_STRING)
    extern uint8 USBFS_PC_idSerialNumberStringDescriptor[USBFS_PC_IDSN_DESCR_LENGTH];
#endif /* (USBFS_PC_ENABLE_IDSN_STRING) */

extern volatile uint8 USBFS_PC_interfaceNumber;
extern volatile uint8 USBFS_PC_interfaceSetting[USBFS_PC_MAX_INTERFACES_NUMBER];
extern volatile uint8 USBFS_PC_interfaceSettingLast[USBFS_PC_MAX_INTERFACES_NUMBER];
extern volatile uint8 USBFS_PC_deviceAddress;
extern volatile uint8 USBFS_PC_interfaceStatus[USBFS_PC_MAX_INTERFACES_NUMBER];
extern const uint8 CYCODE *USBFS_PC_interfaceClass;

extern volatile T_USBFS_PC_EP_CTL_BLOCK USBFS_PC_EP[USBFS_PC_MAX_EP];
extern volatile T_USBFS_PC_TD USBFS_PC_currentTD;

#if (USBFS_PC_EP_MANAGEMENT_DMA)
    #if (CY_PSOC4)
        extern const uint8 USBFS_PC_DmaChan[USBFS_PC_MAX_EP];
    #else
        extern uint8 USBFS_PC_DmaChan[USBFS_PC_MAX_EP];
        extern uint8 USBFS_PC_DmaTd  [USBFS_PC_MAX_EP];
    #endif /* (CY_PSOC4) */
#endif /* (USBFS_PC_EP_MANAGEMENT_DMA) */

#if (USBFS_PC_EP_MANAGEMENT_DMA_AUTO)
#if (CY_PSOC4)
    extern uint8  USBFS_PC_DmaEpBurstCnt   [USBFS_PC_MAX_EP];
    extern uint8  USBFS_PC_DmaEpLastBurstEl[USBFS_PC_MAX_EP];

    extern uint8  USBFS_PC_DmaEpBurstCntBackup  [USBFS_PC_MAX_EP];
    extern uint32 USBFS_PC_DmaEpBufferAddrBackup[USBFS_PC_MAX_EP];
    
    extern const uint8 USBFS_PC_DmaReqOut     [USBFS_PC_MAX_EP];    
    extern const uint8 USBFS_PC_DmaBurstEndOut[USBFS_PC_MAX_EP];
#else
    #if (USBFS_PC_EP_DMA_AUTO_OPT == 0u)
        extern uint8 USBFS_PC_DmaNextTd[USBFS_PC_MAX_EP];
        extern volatile uint16 USBFS_PC_inLength [USBFS_PC_MAX_EP];
        extern volatile uint8  USBFS_PC_inBufFull[USBFS_PC_MAX_EP];
        extern const uint8 USBFS_PC_epX_TD_TERMOUT_EN[USBFS_PC_MAX_EP];
        extern const uint8 *USBFS_PC_inDataPointer[USBFS_PC_MAX_EP];
    #endif /* (USBFS_PC_EP_DMA_AUTO_OPT == 0u) */
#endif /* CY_PSOC4 */
#endif /* (USBFS_PC_EP_MANAGEMENT_DMA_AUTO) */

extern volatile uint8 USBFS_PC_ep0Toggle;
extern volatile uint8 USBFS_PC_lastPacketSize;
extern volatile uint8 USBFS_PC_ep0Mode;
extern volatile uint8 USBFS_PC_ep0Count;
extern volatile uint16 USBFS_PC_transferByteCount;


/***************************************
*     Private Function Prototypes
***************************************/
void  USBFS_PC_ReInitComponent(void)            ;
void  USBFS_PC_HandleSetup(void)                ;
void  USBFS_PC_HandleIN(void)                   ;
void  USBFS_PC_HandleOUT(void)                  ;
void  USBFS_PC_LoadEP0(void)                    ;
uint8 USBFS_PC_InitControlRead(void)            ;
uint8 USBFS_PC_InitControlWrite(void)           ;
void  USBFS_PC_ControlReadDataStage(void)       ;
void  USBFS_PC_ControlReadStatusStage(void)     ;
void  USBFS_PC_ControlReadPrematureStatus(void) ;
uint8 USBFS_PC_InitControlWrite(void)           ;
uint8 USBFS_PC_InitZeroLengthControlTransfer(void) ;
void  USBFS_PC_ControlWriteDataStage(void)      ;
void  USBFS_PC_ControlWriteStatusStage(void)    ;
void  USBFS_PC_ControlWritePrematureStatus(void);
uint8 USBFS_PC_InitNoDataControlTransfer(void)  ;
void  USBFS_PC_NoDataControlStatusStage(void)   ;
void  USBFS_PC_InitializeStatusBlock(void)      ;
void  USBFS_PC_UpdateStatusBlock(uint8 completionCode) ;
uint8 USBFS_PC_DispatchClassRqst(void)          ;

void USBFS_PC_Config(uint8 clearAltSetting) ;
void USBFS_PC_ConfigAltChanged(void)        ;
void USBFS_PC_ConfigReg(void)               ;
void USBFS_PC_EpStateInit(void)             ;


const T_USBFS_PC_LUT CYCODE *USBFS_PC_GetConfigTablePtr(uint8 confIndex);
const T_USBFS_PC_LUT CYCODE *USBFS_PC_GetDeviceTablePtr(void)           ;
#if (USBFS_PC_BOS_ENABLE)
    const T_USBFS_PC_LUT CYCODE *USBFS_PC_GetBOSPtr(void)               ;
#endif /* (USBFS_PC_BOS_ENABLE) */
const uint8 CYCODE *USBFS_PC_GetInterfaceClassTablePtr(void)                    ;
uint8 USBFS_PC_ClearEndpointHalt(void)                                          ;
uint8 USBFS_PC_SetEndpointHalt(void)                                            ;
uint8 USBFS_PC_ValidateAlternateSetting(void)                                   ;

void USBFS_PC_SaveConfig(void)      ;
void USBFS_PC_RestoreConfig(void)   ;

#if (CY_PSOC3 || CY_PSOC5LP)
    #if (USBFS_PC_EP_MANAGEMENT_DMA_AUTO && (USBFS_PC_EP_DMA_AUTO_OPT == 0u))
        void USBFS_PC_LoadNextInEP(uint8 epNumber, uint8 mode)  ;
    #endif /* (USBFS_PC_EP_MANAGEMENT_DMA_AUTO && (USBFS_PC_EP_DMA_AUTO_OPT == 0u)) */
#endif /* (CY_PSOC3 || CY_PSOC5LP) */

#if defined(USBFS_PC_ENABLE_IDSN_STRING)
    void USBFS_PC_ReadDieID(uint8 descr[])  ;
#endif /* USBFS_PC_ENABLE_IDSN_STRING */

#if defined(USBFS_PC_ENABLE_HID_CLASS)
    uint8 USBFS_PC_DispatchHIDClassRqst(void) ;
#endif /* (USBFS_PC_ENABLE_HID_CLASS) */

#if defined(USBFS_PC_ENABLE_AUDIO_CLASS)
    uint8 USBFS_PC_DispatchAUDIOClassRqst(void) ;
#endif /* (USBFS_PC_ENABLE_AUDIO_CLASS) */

#if defined(USBFS_PC_ENABLE_CDC_CLASS)
    uint8 USBFS_PC_DispatchCDCClassRqst(void) ;
#endif /* (USBFS_PC_ENABLE_CDC_CLASS) */

#if (USBFS_PC_ENABLE_MSC_CLASS)
    #if (USBFS_PC_HANDLE_MSC_REQUESTS)
        uint8 USBFS_PC_DispatchMSCClassRqst(void) ;
    #endif /* (USBFS_PC_HANDLE_MSC_REQUESTS) */
#endif /* (USBFS_PC_ENABLE_MSC_CLASS */

CY_ISR_PROTO(USBFS_PC_EP_0_ISR);
CY_ISR_PROTO(USBFS_PC_BUS_RESET_ISR);

#if (USBFS_PC_SOF_ISR_ACTIVE)
    CY_ISR_PROTO(USBFS_PC_SOF_ISR);
#endif /* (USBFS_PC_SOF_ISR_ACTIVE) */

#if (USBFS_PC_EP1_ISR_ACTIVE)
    CY_ISR_PROTO(USBFS_PC_EP_1_ISR);
#endif /* (USBFS_PC_EP1_ISR_ACTIVE) */

#if (USBFS_PC_EP2_ISR_ACTIVE)
    CY_ISR_PROTO(USBFS_PC_EP_2_ISR);
#endif /* (USBFS_PC_EP2_ISR_ACTIVE) */

#if (USBFS_PC_EP3_ISR_ACTIVE)
    CY_ISR_PROTO(USBFS_PC_EP_3_ISR);
#endif /* (USBFS_PC_EP3_ISR_ACTIVE) */

#if (USBFS_PC_EP4_ISR_ACTIVE)
    CY_ISR_PROTO(USBFS_PC_EP_4_ISR);
#endif /* (USBFS_PC_EP4_ISR_ACTIVE) */

#if (USBFS_PC_EP5_ISR_ACTIVE)
    CY_ISR_PROTO(USBFS_PC_EP_5_ISR);
#endif /* (USBFS_PC_EP5_ISR_ACTIVE) */

#if (USBFS_PC_EP6_ISR_ACTIVE)
    CY_ISR_PROTO(USBFS_PC_EP_6_ISR);
#endif /* (USBFS_PC_EP6_ISR_ACTIVE) */

#if (USBFS_PC_EP7_ISR_ACTIVE)
    CY_ISR_PROTO(USBFS_PC_EP_7_ISR);
#endif /* (USBFS_PC_EP7_ISR_ACTIVE) */

#if (USBFS_PC_EP8_ISR_ACTIVE)
    CY_ISR_PROTO(USBFS_PC_EP_8_ISR);
#endif /* (USBFS_PC_EP8_ISR_ACTIVE) */

#if (USBFS_PC_EP_MANAGEMENT_DMA)
    CY_ISR_PROTO(USBFS_PC_ARB_ISR);
#endif /* (USBFS_PC_EP_MANAGEMENT_DMA) */

#if (USBFS_PC_DP_ISR_ACTIVE)
    CY_ISR_PROTO(USBFS_PC_DP_ISR);
#endif /* (USBFS_PC_DP_ISR_ACTIVE) */

#if (CY_PSOC4)
    CY_ISR_PROTO(USBFS_PC_INTR_HI_ISR);
    CY_ISR_PROTO(USBFS_PC_INTR_MED_ISR);
    CY_ISR_PROTO(USBFS_PC_INTR_LO_ISR);
    #if (USBFS_PC_LPM_ACTIVE)
        CY_ISR_PROTO(USBFS_PC_LPM_ISR);
    #endif /* (USBFS_PC_LPM_ACTIVE) */
#endif /* (CY_PSOC4) */

#if (USBFS_PC_EP_MANAGEMENT_DMA_AUTO)
#if (CY_PSOC4)
    #if (USBFS_PC_DMA1_ACTIVE)
        void USBFS_PC_EP1_DMA_DONE_ISR(void);
    #endif /* (USBFS_PC_DMA1_ACTIVE) */

    #if (USBFS_PC_DMA2_ACTIVE)
        void USBFS_PC_EP2_DMA_DONE_ISR(void);
    #endif /* (USBFS_PC_DMA2_ACTIVE) */

    #if (USBFS_PC_DMA3_ACTIVE)
        void USBFS_PC_EP3_DMA_DONE_ISR(void);
    #endif /* (USBFS_PC_DMA3_ACTIVE) */

    #if (USBFS_PC_DMA4_ACTIVE)
        void USBFS_PC_EP4_DMA_DONE_ISR(void);
    #endif /* (USBFS_PC_DMA4_ACTIVE) */

    #if (USBFS_PC_DMA5_ACTIVE)
        void USBFS_PC_EP5_DMA_DONE_ISR(void);
    #endif /* (USBFS_PC_DMA5_ACTIVE) */

    #if (USBFS_PC_DMA6_ACTIVE)
        void USBFS_PC_EP6_DMA_DONE_ISR(void);
    #endif /* (USBFS_PC_DMA6_ACTIVE) */

    #if (USBFS_PC_DMA7_ACTIVE)
        void USBFS_PC_EP7_DMA_DONE_ISR(void);
    #endif /* (USBFS_PC_DMA7_ACTIVE) */

    #if (USBFS_PC_DMA8_ACTIVE)
        void USBFS_PC_EP8_DMA_DONE_ISR(void);
    #endif /* (USBFS_PC_DMA8_ACTIVE) */

#else
    #if (USBFS_PC_EP_DMA_AUTO_OPT == 0u)
        CY_ISR_PROTO(USBFS_PC_EP_DMA_DONE_ISR);
    #endif /* (USBFS_PC_EP_DMA_AUTO_OPT == 0u) */
#endif /* (CY_PSOC4) */
#endif /* (USBFS_PC_EP_MANAGEMENT_DMA_AUTO) */


/***************************************
*         Request Handlers
***************************************/

uint8 USBFS_PC_HandleStandardRqst(void) ;
uint8 USBFS_PC_DispatchClassRqst(void)  ;
uint8 USBFS_PC_HandleVendorRqst(void)   ;


/***************************************
*    HID Internal references
***************************************/

#if defined(USBFS_PC_ENABLE_HID_CLASS)
    void USBFS_PC_FindReport(void)            ;
    void USBFS_PC_FindReportDescriptor(void)  ;
    void USBFS_PC_FindHidClassDecriptor(void) ;
#endif /* USBFS_PC_ENABLE_HID_CLASS */


/***************************************
*    MIDI Internal references
***************************************/

#if defined(USBFS_PC_ENABLE_MIDI_STREAMING)
    void USBFS_PC_MIDI_IN_EP_Service(void)  ;
#endif /* (USBFS_PC_ENABLE_MIDI_STREAMING) */


/***************************************
*    CDC Internal references
***************************************/

#if defined(USBFS_PC_ENABLE_CDC_CLASS)

    typedef struct
    {
        uint8  bRequestType;
        uint8  bNotification;
        uint8  wValue;
        uint8  wValueMSB;
        uint8  wIndex;
        uint8  wIndexMSB;
        uint8  wLength;
        uint8  wLengthMSB;
        uint8  wSerialState;
        uint8  wSerialStateMSB;
    } t_USBFS_PC_cdc_notification;

    uint8 USBFS_PC_GetInterfaceComPort(uint8 interface) ;
    uint8 USBFS_PC_Cdc_EpInit( const T_USBFS_PC_EP_SETTINGS_BLOCK CYCODE *pEP, uint8 epNum, uint8 cdcComNums) ;

    extern volatile uint8  USBFS_PC_cdc_dataInEpList[USBFS_PC_MAX_MULTI_COM_NUM];
    extern volatile uint8  USBFS_PC_cdc_dataOutEpList[USBFS_PC_MAX_MULTI_COM_NUM];
    extern volatile uint8  USBFS_PC_cdc_commInEpList[USBFS_PC_MAX_MULTI_COM_NUM];
#endif /* (USBFS_PC_ENABLE_CDC_CLASS) */


#endif /* CY_USBFS_USBFS_PC_pvt_H */


/* [] END OF FILE */
