/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"

uint8 button_flag;
uint8 select_flag;      // for isr_Select. 0 = no time_out, 1 = time-out
uint8 buffer[50];
uint8 I2C_buffer[1];
uint16 USB_buffer_length;
uint8 buffer_counter;
uint8 x;
uint8 y;
//uint8 joy_button_state; // bits 0-7 represent joy button state (1=ON, 0=OFF)
uint8 joy_mode;         // 0 = normal, 1 = joys flipped, 2 = touch pad

// Button config pointers
uint8* joy1_1;
uint8* joy1_2;
uint8* joy1_3;
uint8* joy1_4;
uint8* joy2_1;
uint8* joy2_2;
uint8* joy2_3;
uint8* joy2_4;

struct {
  uint8  l_joystick_x;
  uint8  l_joystick_y;
  uint8  r_joystick_x;
  uint8  r_joystick_y;
  uint8  accel_x;
  uint8  accel_y; 
  uint8  l2; 
  uint8  r2;   
  
  uint8  button_left;
  uint8  button_down;
  uint8  button_right;
  uint8  button_up;  
  uint8  button_square;
  uint8  button_x;
  uint8  button_circle;
  uint8  button_triangle;   
  
  uint8  button_l1;
  uint8  button_r1;
  uint8  button_l2;
  uint8  button_r2;  
  uint8  button_share;  
  uint8  button_options;
  uint8  button_l3;
  uint8  button_r3;
  
  uint8  button_ps4;  
  uint8  button_tpad;    
   
  uint8  tpad_x;  
  uint8  tpad_y;    
  uint8  battery;
} ps4;

// Button pointer map table
uint8 *pointermap[15];

/* [] END OF FILE */

/*

The PS4 adapter must set the following parameters via the serial port:
    SERIAL OFF
    HEX OFF
This can be done by:
    * Connecting a USB cable between the PSOC target board (USB-A) and a PC
    * Hit the button on the PSOC target board to enumerate the USB (enter serial terminal mode)
    * Get COM Port # from computer (PC or MAC)
    * Use a terminal emulator to send the above mentioned commands to the PS4 adapter (https://www.compuphase.com/software_termite.htm)
    * When done, hit the button again to leave serial terminal mode



I2C Registers

Analog Data
0	Left Joystick X
1	Left Joystick Y
2	Right Joystick X
3	Right Joystick Y
4	Accelerometer X
5	Accelerometer Y
6	L2
7	R2

Buttons_1
8
    bits 0-3	Compas Pad Button Press
        These 4 bits are treated as a item with the following value
        0 = N
        1 = NE
        2 = E
        3 = SE
        4 = S
        5 = SW
        6 = W
        7 = NW
        8 = No button pressed
    8 bit 4	Square
    8 bit 5	X
    8 bit 6	Circle
    8 bit 7	Triangle

Buttons_2
Register 9
    9 bit 0	L1
    9 bit 1	R1
    9 bit 2	L2
    9 bit 3	R2
    9 bit 4	Share
    9 bit 5	Options
    9 bit 6	L3
    9 bit 7	R3

Button_3
Register 10
    10 bit 0	PS4
    10 bit 1	TPad

Trackpad
11	TPad X
12	TPad Y

Battery Voltage
13	Battery Voltage (values from 0-15)

*/